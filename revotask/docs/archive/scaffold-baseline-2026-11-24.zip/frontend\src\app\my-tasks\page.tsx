export default function Page() {
  return (
    <main className="mx-auto max-w-5xl p-8">
      <h1 className="text-2xl font-semibold">my-tasks</h1>
      <p className="mt-3 text-slate-600">My Tasks: fetch cards assigned to current user and group by board name.</p>
      <p className="mt-2 text-sm text-amber-700">Implementation pending — see .kiro/specs/.</p>
    </main>
  );
}
