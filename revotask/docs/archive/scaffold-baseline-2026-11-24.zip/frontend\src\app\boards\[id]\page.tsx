export default function Page() {
  return (
    <main className="mx-auto max-w-5xl p-8">
      <h1 className="text-2xl font-semibold">boards</h1>
      <p className="mt-3 text-slate-600">Board detail: render columns/cards in a Kanban layout; server-fetch board detail.</p>
      <p className="mt-2 text-sm text-amber-700">Implementation pending — see .kiro/specs/.</p>
    </main>
  );
}
