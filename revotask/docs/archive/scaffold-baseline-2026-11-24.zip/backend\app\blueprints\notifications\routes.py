# Register notifications endpoints here. Keep handlers thin; delegate business logic to service.py.
from . import notifications_bp
