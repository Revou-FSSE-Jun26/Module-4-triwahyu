# Permission Matrix

| Action | Anonymous | Board member | Board administrator |
|---|---:|---:|---:|
| Register / login | Yes | Yes | Yes |
| Read own profile | No | Yes | Yes |
| Create board | No | Yes | Yes |
| Read board | No | Membership required | Membership required |
| Manage board settings | No | Per policy; default owner/admin only | Yes |
| Manage members | No | No | Yes |
| Create/move cards | No | Yes | Yes |
| Edit/delete own comment | No | Yes, own comment | Yes, subject to policy |
| Read board analytics | No | Per policy | Yes |

This matrix is a starting contract. Confirm board ownership and admin semantics in the relevant feature specification before implementation.
