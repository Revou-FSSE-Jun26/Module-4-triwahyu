# Register auth endpoints here. Keep handlers thin; delegate business logic to service.py.
from . import auth_bp
