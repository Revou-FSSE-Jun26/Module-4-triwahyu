from flask import Flask, jsonify
from flask_cors import CORS
from .extensions import db, migrate, jwt


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_mapping(
        SECRET_KEY="dev-only-change-me",
        JWT_SECRET_KEY="dev-only-change-me",
        SQLALCHEMY_DATABASE_URI="sqlite:///revotask.db",
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
    )
    if test_config:
        app.config.update(test_config)

    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    CORS(app, origins=app.config.get("CORS_ORIGINS", ["http://localhost:3000"]))

    from . import models  # noqa: F401
    from .blueprints.health import health_bp
    app.register_blueprint(health_bp, url_prefix="/api")

    @app.get("/")
    def index():
        return jsonify({"data": {"service": "RevoTask API"}}), 200

    return app
