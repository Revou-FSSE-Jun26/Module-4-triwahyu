"use client";

import type { ReactNode } from "react";

type Props = { open: boolean; title: string; onClose: () => void; children: ReactNode };

export function BaseModal({ open, title, onClose, children }: Props) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" role="presentation" onMouseDown={onClose}>
      <section
        aria-modal="true"
        aria-labelledby="modal-title"
        className="w-full max-w-lg rounded-xl bg-white p-6 shadow-xl"
        role="dialog"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 id="modal-title" className="text-lg font-semibold">{title}</h2>
          <button aria-label="Close dialog" className="rounded p-2 hover:bg-slate-100" onClick={onClose}>×</button>
        </div>
        {children}
      </section>
    </div>
  );
}
