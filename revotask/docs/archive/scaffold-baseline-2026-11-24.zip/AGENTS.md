# Agent entry point
Read `.kiro/steering/product.md`, `tech.md`, `structure.md`, and `coding-standards.md` first.
For backend work, also read `backend.md`; for frontend work, read `frontend.md`.
For tests, read `testing.md`. Feature source of truth lives in `.kiro/specs/<feature>/`.
Follow `docs/contracts/` for cross-feature behavior. Do not implement beyond the active brief.
Review generated output, run relevant checks, and record refinements before committing.
