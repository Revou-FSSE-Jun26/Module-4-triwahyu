export default function Page() {
  return (
    <main className="mx-auto max-w-5xl p-8">
      <h1 className="text-2xl font-semibold">login</h1>
      <p className="mt-3 text-slate-600">Login form: POST /api/auth/login; store session using the approved AuthContext/session design.</p>
      <p className="mt-2 text-sm text-amber-700">Implementation pending — see .kiro/specs/.</p>
    </main>
  );
}
