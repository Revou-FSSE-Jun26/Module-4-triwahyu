# Authentication and Users — Requirements

## Scope
Registration, login, JWT lifecycle, current-user profile retrieval, and profile updates.

## Requirements and acceptance criteria
