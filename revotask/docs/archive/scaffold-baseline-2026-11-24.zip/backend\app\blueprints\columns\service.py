# Columns business logic. Keep authorization and domain rules in this layer.
