# RevoTask — AI-Native Monorepo

Trello-like task management application built with a spec-driven, AI-assisted workflow.

## Product roles
- **Board members:** create/manage boards, organize columns, move cards, collaborate through comments, and track assigned tasks.
- **Board administrators:** manage member access, oversee board cards, and monitor activity through analytics and notifications.

## Monorepo layout
- `.kiro/`: persistent agent context, feature specifications, agent roles, hooks, and reusable skills.
- `backend/`: Flask modular monolith and REST API.
- `frontend/`: Next.js application.
- `contracts/`: generated, committed OpenAPI contract.
- `docs/`: product docs, behavioral contracts, ADRs, and design-system guidance.
- `scripts/`: API export and requirement traceability utilities.

## Technology
Next.js, React, TypeScript, Tailwind CSS, Flask, SQLAlchemy, Flask-Migrate, Flask-JWT-Extended,
Marshmallow, PostgreSQL, Pytest, React Testing Library, Playwright, Railway, Vercel, Kiro IDE, Kiro CLI.

## Local development
### Prerequisites
- Python 3.11+
- Node.js 20+
- Docker + Docker Compose
- PostgreSQL (or use the Compose service)

### Start infrastructure
```bash
docker compose up -d postgres
```

### Backend
```bash
cd backend
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
flask --app app:create_app db upgrade
flask --app app:create_app run --debug
```

### Frontend
```bash
cd frontend
npm install
cp .env.example .env.local
npm run dev
```

Frontend: http://localhost:3000  
Backend: http://localhost:5000

## Quality commands
From repository root:
```bash
make lint
make test
make openapi
make traceability
```

Backend:
```bash
cd backend && pytest -v
```

Frontend:
```bash
cd frontend && npm test
```

Playwright:
```bash
cd frontend
npx playwright install
npx playwright test
npx playwright show-report
```

## AI-native workflow
1. Refine the project brief and feature requirements.
2. Generate and review requirements, design, and tasks in `.kiro/specs/`.
3. Define and enforce rules in `.kiro/steering/`.
4. Implement one vertical feature slice at a time.
5. Generate tests alongside implementation and review AI output.
6. Record refinement decisions in each feature's `CHANGELOG.md`.
7. Export OpenAPI and check requirement-to-test traceability.
8. Deploy backend to Railway and frontend to Vercel.

## Important implementation status
This repository is an architectural starter scaffold. Feature specifications, project conventions,
configuration, and initial application entry points are provided. Feature endpoints, persistence,
UI flows, migrations, and production tests must be implemented and verified before deployment.
Do not represent placeholder endpoints or tests as completed deliverables.

## Environment variables
See `backend/.env.example` and `frontend/.env.example`. Never commit real `.env` or `.env.local` files.
