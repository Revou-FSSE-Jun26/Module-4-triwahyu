# Repository Structure Rules
- Keep API implementation in `backend/app/blueprints/<feature>/`.
- Each required blueprint has `routes.py`, `service.py`, and `schema.py`.
- Keep shared persistence models in `backend/app/models/`; migrations in `backend/migrations/`.
- Keep Next.js routes in `frontend/src/app/`; shared UI in `frontend/src/components/shared/`.
- Shared client hooks belong in `frontend/src/hooks/`; API and error utilities in `frontend/src/lib/`.
- One feature folder in `.kiro/specs/` contains `requirements.md`, `design.md`, `tasks.md`, and `CHANGELOG.md`.
- OpenAPI is generated from backend code into `contracts/openapi.json`; do not hand-edit generated output.
- Keep root `AGENTS.md` concise and point agents to steering files.
- Avoid duplicate sources of truth for API contracts, permissions, ordering, and error envelopes.
