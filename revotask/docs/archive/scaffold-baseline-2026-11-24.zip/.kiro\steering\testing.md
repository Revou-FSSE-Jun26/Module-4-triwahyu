---
inclusion: fileMatch
fileMatchPattern: "**/tests/**, **/*.test.*, **/*.spec.*, e2e/**"
---
# Testing Guidelines

## Rule: test behavior, not implementation details
Rationale: tests should protect user-visible contracts while allowing refactors.
Example: assert a card appears in its destination column after a move.

## Rule: cover positive and negative paths
Rationale: authorization and validation failures are core behavior.
Example: comments tests cover 201, 400, 401, and 403.

## Rule: avoid fixed sleeps in browser tests
Rationale: arbitrary delays create slow and flaky tests.
Example: use Playwright locator assertions and response waits instead of `waitForTimeout`.

## Rule: isolate test data
Rationale: tests must be repeatable and safe to run in any order.
Example: create uniquely named boards and clean up fixtures after each test.
