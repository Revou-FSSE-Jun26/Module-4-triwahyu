"use client";

// Implement 30-second polling with cleanup, loading/error state, and unread count.
// Avoid overlapping requests and stop polling when the consumer unmounts.
export function useNotifications() {
  return { notifications: [], unreadCount: 0, isLoading: false };
}
