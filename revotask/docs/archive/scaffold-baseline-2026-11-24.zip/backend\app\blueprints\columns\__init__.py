from flask import Blueprint

columns_bp = Blueprint("columns", __name__)
