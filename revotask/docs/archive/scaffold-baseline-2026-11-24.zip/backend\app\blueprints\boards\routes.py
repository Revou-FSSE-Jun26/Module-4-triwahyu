# Register boards endpoints here. Keep handlers thin; delegate business logic to service.py.
from . import boards_bp
