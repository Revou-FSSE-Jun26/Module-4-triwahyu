# Marshmallow request/response schemas for notifications.
