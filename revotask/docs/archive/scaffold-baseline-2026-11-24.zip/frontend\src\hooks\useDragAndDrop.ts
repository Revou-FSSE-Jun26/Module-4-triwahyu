"use client";

// Implement native HTML5 drag/drop, optimistic state update, PATCH persistence,
// and rollback on ApiError according to docs/contracts/ordering.md.
export function useDragAndDrop() {
  return {
    onDragStart: (_cardId: string) => undefined,
    onDrop: async (_cardId: string, _columnId: string, _order: number) => {
      throw new Error("useDragAndDrop is a scaffold; implement the feature slice first.");
    },
  };
}
