# RevoTask Design System

Define tokens for color, spacing, typography, radius, elevation, and responsive breakpoints before polishing screens.
Shared components: `BaseButton`, `BaseBadge`, and `BaseModal`.
Use accessible labels, keyboard focus states, semantic HTML, and responsive Kanban behavior.
CaliStore references are inspiration/reference only; do not copy proprietary assets.
