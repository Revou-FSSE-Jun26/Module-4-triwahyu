"""Basic traceability guard for REQ IDs across specs and tests."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
specs = list((ROOT / ".kiro" / "specs").glob("*/requirements.md"))
requirements = set()
for path in specs:
    requirements.update(re.findall(r"REQ-[A-Z]+-\d+", path.read_text(encoding="utf-8")))

if not requirements:
    print("No REQ-ID entries found yet; add IDs to requirements before enforcing traceability.")
    sys.exit(0)

corpus = "\n".join(
    p.read_text(encoding="utf-8", errors="ignore")
    for folder in ("backend", "frontend")
    for p in (ROOT / folder).rglob("*")
    if p.is_file() and p.suffix in {".py", ".ts", ".tsx"}
)
missing = sorted(req for req in requirements if req not in corpus)
if missing:
    print("Requirements without a test/code trace reference:", ", ".join(missing))
    sys.exit(1)
print(f"Traceability references found for {len(requirements)} requirements.")
