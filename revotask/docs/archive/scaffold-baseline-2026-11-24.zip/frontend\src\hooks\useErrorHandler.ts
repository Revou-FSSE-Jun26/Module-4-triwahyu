"use client";

import { useCallback } from "react";
import { ApiError } from "@/lib/errors";
import { notify } from "@/lib/toast";

export function useErrorHandler() {
  return useCallback((error: unknown) => {
    if (error instanceof ApiError) {
      notify.error(error.message);
      return;
    }
    notify.error("An unexpected error occurred. Please try again.");
  }, []);
}
