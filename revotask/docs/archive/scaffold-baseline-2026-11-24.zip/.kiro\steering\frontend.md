---
inclusion: fileMatch
fileMatchPattern: "frontend/**"
---
# Frontend Guidelines

## Rule: use TypeScript strict mode
Rationale: explicit types catch API and UI contract drift.
Example: type board, column, card, and comment responses in `src/types/`.

## Rule: centralize HTTP behavior
Rationale: token attachment and error mapping must be consistent.
Example: components call typed functions from `src/lib/apiClient.ts`, not raw `fetch` scattered across the UI.

## Rule: use shared components for repeated UI
Rationale: consistent interaction and accessibility reduce defects.
Example: use `BaseButton`, `BaseBadge`, and `BaseModal` for common actions and dialogs.

## Rule: protect routes and handle expired sessions
Rationale: client-side navigation alone is not security.
Example: protected pages require a valid session and backend endpoints independently enforce JWT authorization.

## Rule: use optimistic updates only with rollback
Rationale: drag-and-drop should feel immediate without hiding failed persistence.
Example: `useDragAndDrop` restores the original position if PATCH fails.
