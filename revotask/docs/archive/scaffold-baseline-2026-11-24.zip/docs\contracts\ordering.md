# Ordering Contract

- Column reorder follows the assignment's FLOAT order strategy.
- Card position is represented by a positive floating-point `order` value.
- `PATCH /api/cards/<id>/position` accepts a validated UUID `column_id` and positive float `order` through `CardPositionSchema`.
- Validate that the destination column belongs to a board the actor can access.
- Define collision/rebalancing behavior and concurrent-move handling in the feature design before implementation.
