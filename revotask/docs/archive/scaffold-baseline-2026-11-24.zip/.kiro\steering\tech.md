# Canonical Technology Stack
- Frontend: Next.js App Router, React, TypeScript, Tailwind CSS.
- Backend: Python, Flask modular monolith, SQLAlchemy, Flask-Migrate, Flask-JWT-Extended, Marshmallow.
- Database: PostgreSQL.
- Frontend feedback: react-hot-toast.
- Tests: Pytest, React Testing Library, Playwright.
- Deployment targets: Railway (Flask API), Vercel (Next.js).
- API base URL: `API_BASE_URL` on server; `NEXT_PUBLIC_API_BASE_URL` in browser.
- Keep dependency versions pinned or bounded in the relevant manifest; review upgrades deliberately.
