"use client";

// Connect useNotifications and show the unread notification count.
export function NotificationBell() {
  return <button type="button" aria-label="Notifications">Notifications</button>;
}
