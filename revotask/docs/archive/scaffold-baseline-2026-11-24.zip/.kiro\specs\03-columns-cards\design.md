# Columns and Cards — Design

## Context
Column CRUD and ordering; card CRUD, assignment, search, drag-and-drop position updates, and persistence.

## API and UI mapping
Document each requirement ID, Flask route or Next.js page/component, service, schema, persistence model, and authorization rule here.

## Data and failure behavior
Reference `docs/contracts/error-contract.md`, `permission-matrix.md`, and `ordering.md` where applicable.
