# Marshmallow request/response schemas for boards.
