# Notifications — Requirements

## Scope
Paginated notifications, read state, polling, and unread count.

## Requirements and acceptance criteria
