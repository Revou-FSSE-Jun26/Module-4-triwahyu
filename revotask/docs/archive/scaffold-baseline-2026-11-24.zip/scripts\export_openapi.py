"""Export the Flask API OpenAPI document.

Replace the placeholder exporter with the chosen OpenAPI integration once route schemas
are implemented. The generated file is committed and drift-checked in CI.
"""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "contracts" / "openapi.json"

def main() -> None:
    if not TARGET.exists():
        TARGET.write_text(json.dumps({
            "openapi": "3.0.3",
            "info": {"title": "RevoTask API", "version": "0.1.0"},
            "paths": {},
        }, indent=2) + "\n", encoding="utf-8")
    print(f"OpenAPI target ready: {TARGET}")

if __name__ == "__main__":
    main()
