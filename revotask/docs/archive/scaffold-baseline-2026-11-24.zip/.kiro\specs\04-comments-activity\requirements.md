# Comments and Activity — Requirements

## Scope
Card comments, owner-only edit/delete, and activity records needed by collaboration views.

## Requirements and acceptance criteria
