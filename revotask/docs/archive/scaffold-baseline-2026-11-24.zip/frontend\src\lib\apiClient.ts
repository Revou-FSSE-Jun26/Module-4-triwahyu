import { ApiError } from "./errors";

type ApiEnvelope<T> = { data: T } | { error: { code?: string; message: string } };

const isServer = typeof window === "undefined";
const baseUrl = isServer
  ? process.env.API_BASE_URL
  : process.env.NEXT_PUBLIC_API_BASE_URL;

export async function apiRequest<T>(
  path: string,
  init: RequestInit = {},
  token?: string,
): Promise<T> {
  if (!baseUrl) throw new Error("API base URL is not configured");

  const headers = new Headers(init.headers);
  if (init.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  if (token) headers.set("Authorization", `Bearer ${token}`);

  const response = await fetch(`${baseUrl}${path}`, {
    ...init,
    headers,
    cache: init.cache ?? "no-store",
  });

  const payload = (await response.json().catch(() => null)) as ApiEnvelope<T> | null;
  if (!response.ok) {
    const error = payload && "error" in payload ? payload.error : undefined;
    throw new ApiError(
      error?.message ?? "Something went wrong. Please try again.",
      response.status,
      error?.code,
    );
  }
  if (!payload || !("data" in payload)) {
    throw new ApiError("Invalid API response", response.status);
  }
  return payload.data;
}
