# Import model modules here so Flask-Migrate can discover metadata.
