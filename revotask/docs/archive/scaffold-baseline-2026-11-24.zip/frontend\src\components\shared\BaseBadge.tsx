import type { ReactNode } from "react";

type Props = { children: ReactNode; color?: "gray" | "blue" | "green" | "red" };
const colors = {
  gray: "bg-slate-100 text-slate-700",
  blue: "bg-blue-100 text-blue-700",
  green: "bg-green-100 text-green-700",
  red: "bg-red-100 text-red-700",
};

export function BaseBadge({ children, color = "gray" }: Props) {
  return <span className={`inline-flex rounded-full px-2 py-1 text-xs ${colors[color]}`}>{children}</span>;
}
