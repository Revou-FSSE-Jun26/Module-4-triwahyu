# Marshmallow request/response schemas for analytics.
