# Marshmallow request/response schemas for columns.
