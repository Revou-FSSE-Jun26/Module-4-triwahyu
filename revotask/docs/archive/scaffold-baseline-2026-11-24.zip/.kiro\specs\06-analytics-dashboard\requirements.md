# Analytics and Dashboard — Requirements

## Scope
Board analytics and dashboard summaries, including weekly completed-card counts and member activity.

## Requirements and acceptance criteria
