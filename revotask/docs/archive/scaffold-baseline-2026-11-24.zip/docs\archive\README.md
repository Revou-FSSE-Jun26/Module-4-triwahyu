# Archive

Place superseded specs or implementation notes here with a date and reason. Prefer Git tags for complete historical snapshots.
