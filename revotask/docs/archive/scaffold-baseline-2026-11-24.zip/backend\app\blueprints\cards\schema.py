# Marshmallow request/response schemas for cards.
