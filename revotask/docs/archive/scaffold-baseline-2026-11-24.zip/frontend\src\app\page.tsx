export default function HomePage() {
  return (
    <main className="mx-auto max-w-5xl p-8">
      <h1 className="text-3xl font-bold">RevoTask</h1>
      <p className="mt-3 text-slate-600">
        Your workspace for boards, columns, cards, and team collaboration.
      </p>
      <p className="mt-6 text-sm text-slate-500">
        Starter scaffold — implement the dashboard data flow from the feature specifications.
      </p>
    </main>
  );
}
