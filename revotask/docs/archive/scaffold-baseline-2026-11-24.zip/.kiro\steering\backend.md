---
inclusion: fileMatch
fileMatchPattern: "backend/**"
---
# Backend Guidelines

## Rule: use thin route handlers
Rationale: HTTP concerns must not be mixed with business rules.
Example: `routes.py` validates input, calls `service.py`, and formats the response.

## Rule: put business logic in services
Rationale: services are reusable and unit-testable without Flask request plumbing.
Example: board ownership and membership checks live in `boards/service.py`.

## Rule: validate with Marshmallow schemas
Rationale: consistent validation prevents malformed data reaching persistence.
Example: `CardPositionSchema` validates UUID `column_id` and positive float `order`.

## Rule: return a consistent JSON envelope
Rationale: clients need predictable success and failure handling.
Example: success uses `{ "data": ... }`; failure uses `{ "error": ... }`.

## Rule: enforce authorization for every resource access
Rationale: UUIDs are identifiers, not access controls.
Example: editing a comment verifies the current user is its owner.
