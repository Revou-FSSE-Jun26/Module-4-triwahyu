# Register columns endpoints here. Keep handlers thin; delegate business logic to service.py.
from . import columns_bp
