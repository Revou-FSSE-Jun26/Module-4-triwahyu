export type User = { id: string; name: string; email: string };
export type Board = { id: string; name: string; columns?: Column[] };
export type Column = { id: string; name: string; order: number; cards?: Card[] };
export type Card = {
  id: string;
  title: string;
  description?: string;
  column_id: string;
  order: number;
  assignee_id?: string | null;
};
export type Comment = { id: string; content: string; user_id: string; created_at: string };
