# API Error Contract

Success:
```json
{ "data": {} }
```

Failure:
```json
{ "error": { "code": "VALIDATION_ERROR", "message": "Request validation failed" } }
```

- Do not expose stack traces, SQL statements, secrets, or internal exception details.
- Use appropriate HTTP status codes (400 validation, 401 unauthenticated, 403 unauthorized, 404 missing resource, 409 conflict, 500 unexpected server error).
- Frontend `ApiError` retains `statusCode` and a safe user-facing message.
