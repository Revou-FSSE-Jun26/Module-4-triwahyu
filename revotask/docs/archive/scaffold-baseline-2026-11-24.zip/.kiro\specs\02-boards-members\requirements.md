# Boards and Members — Requirements

## Scope
Board CRUD, board listing, board detail, membership, and administrator/member permissions.

## Requirements and acceptance criteria
