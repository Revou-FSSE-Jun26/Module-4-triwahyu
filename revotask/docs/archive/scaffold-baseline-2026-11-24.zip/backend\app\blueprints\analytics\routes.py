# Register analytics endpoints here. Keep handlers thin; delegate business logic to service.py.
from . import analytics_bp
