# RevoTask Product Brief

## Overview
RevoTask is a Trello-like task-management application built through a disciplined AI-driven development workflow.

## Personas
- Board member: creates and manages boards, organizes work into columns, moves cards, comments, and tracks assigned tasks.
- Board administrator: manages member access, oversees board cards, and monitors activity through analytics and notifications.

## Core capabilities
JWT authentication, board and column management, card creation and movement, comments, notifications, profile management, card search, and board analytics.

## Non-functional requirements
- Security: protected operations enforce authentication and resource-level authorization on the backend.
- Reliability: persisted card positions remain correct after reload; failed optimistic moves roll back in the UI.
- Maintainability: modular Flask blueprints, typed frontend contracts, feature specs, and shared UI components.
- Testability: acceptance criteria map to automated backend, frontend, and E2E tests.
