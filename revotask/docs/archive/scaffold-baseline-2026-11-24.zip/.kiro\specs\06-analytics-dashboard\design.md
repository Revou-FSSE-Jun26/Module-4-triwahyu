# Analytics and Dashboard — Design

## Context
Board analytics and dashboard summaries, including weekly completed-card counts and member activity.

## API and UI mapping
Document each requirement ID, Flask route or Next.js page/component, service, schema, persistence model, and authorization rule here.

## Data and failure behavior
Reference `docs/contracts/error-contract.md`, `permission-matrix.md`, and `ordering.md` where applicable.
