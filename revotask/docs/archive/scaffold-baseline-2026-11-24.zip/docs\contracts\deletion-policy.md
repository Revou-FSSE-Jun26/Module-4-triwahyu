# Deletion Policy

- Define whether board, column, card, and comment deletion is soft or hard in the corresponding feature design before implementation.
- Respect foreign-key dependencies and the assignment's required `deleted_at` field for Card.
- Do not silently cascade-delete user-owned content without an explicit product rule.
- Record retention and cascade decisions in an ADR and tests.
