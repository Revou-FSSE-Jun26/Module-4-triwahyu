# Comments and Activity — Design

## Context
Card comments, owner-only edit/delete, and activity records needed by collaboration views.

## API and UI mapping
Document each requirement ID, Flask route or Next.js page/component, service, schema, persistence model, and authorization rule here.

## Data and failure behavior
Reference `docs/contracts/error-contract.md`, `permission-matrix.md`, and `ordering.md` where applicable.
