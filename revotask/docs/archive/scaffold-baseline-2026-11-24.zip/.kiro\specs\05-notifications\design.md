# Notifications — Design

## Context
Paginated notifications, read state, polling, and unread count.

## API and UI mapping
Document each requirement ID, Flask route or Next.js page/component, service, schema, persistence model, and authorization rule here.

## Data and failure behavior
Reference `docs/contracts/error-contract.md`, `permission-matrix.md`, and `ordering.md` where applicable.
