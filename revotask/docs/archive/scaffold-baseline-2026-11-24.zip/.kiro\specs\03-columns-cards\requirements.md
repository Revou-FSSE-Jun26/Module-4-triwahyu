# Columns and Cards — Requirements

## Scope
Column CRUD and ordering; card CRUD, assignment, search, drag-and-drop position updates, and persistence.

## Requirements and acceptance criteria
