export default function Page() {
  return (
    <main className="mx-auto max-w-5xl p-8">
      <h1 className="text-2xl font-semibold">profile</h1>
      <p className="mt-3 text-slate-600">Profile: controlled form pre-populated with current user; PATCH /api/users/me.</p>
      <p className="mt-2 text-sm text-amber-700">Implementation pending — see .kiro/specs/.</p>
    </main>
  );
}
