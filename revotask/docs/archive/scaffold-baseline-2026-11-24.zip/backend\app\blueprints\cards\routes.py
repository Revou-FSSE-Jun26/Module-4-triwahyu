# Register cards endpoints here. Keep handlers thin; delegate business logic to service.py.
from . import cards_bp
