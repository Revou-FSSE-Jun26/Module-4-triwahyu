"use client";

// Compose CommentList inside BaseModal and implement comment creation per feature spec.
export function CardDetailModal() {
  return null;
}
