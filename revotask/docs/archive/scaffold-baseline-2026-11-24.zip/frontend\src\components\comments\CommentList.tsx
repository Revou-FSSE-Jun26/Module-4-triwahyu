"use client";

// Render comments, author actions, and empty/loading/error states.
export function CommentList() {
  return null;
}
