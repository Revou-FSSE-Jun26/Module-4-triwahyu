# Cross-Language Coding and Security Standards

## Rule: validate at trust boundaries
Rationale: browser input and API payloads are untrusted.
Example: validate request bodies with Marshmallow and validate form fields before submission.

## Rule: never store plaintext passwords
Rationale: credentials must remain protected if data is exposed.
Example: hash passwords with a maintained password-hashing utility and verify hashes on login.

## Rule: protect private operations on the server
Rationale: hiding a UI control is not authorization.
Example: every board/card/comment mutation checks JWT identity and board membership/role in the service layer.

## Rule: do not leak internal errors
Rationale: stack traces and SQL details expose implementation information.
Example: return the documented `{ "error": { "code": "...", "message": "..." } }` envelope and log details server-side.

## Rule: use explicit types and narrow interfaces
Rationale: clear contracts reduce accidental coupling.
Example: typed frontend API methods return domain types and backend services receive validated data.

## Rule: keep secrets out of source control
Rationale: credentials in Git are difficult to revoke completely.
Example: read `DATABASE_URL` and `JWT_SECRET_KEY` from environment variables; commit only `.env.example`.
